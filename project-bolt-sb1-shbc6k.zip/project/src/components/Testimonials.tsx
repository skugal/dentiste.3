import React from 'react';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Emily Johnson',
    text: 'Dr. Chen is incredibly thorough and caring. She takes the time to listen and explain everything clearly.',
    rating: 5,
  },
  {
    name: 'Michael Smith',
    text: 'Outstanding care and attention to detail. The entire staff is professional and welcoming.',
    rating: 5,
  },
  {
    name: 'Sarah Williams',
    text: 'I appreciate how Dr. Chen focuses on preventive care and overall wellness. Highly recommended!',
    rating: 5,
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Patient Testimonials</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-blue-50 p-6 rounded-xl">
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600 mb-4">{testimonial.text}</p>
              <p className="font-semibold">{testimonial.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}