import React from 'react';
import { Award, BookOpen, Users } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <img
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=800"
              alt="Dr. Sarah Chen"
              className="rounded-2xl shadow-lg"
            />
          </div>
          <div className="md:w-1/2">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">About Dr. Sarah Chen</h2>
            <p className="text-gray-600 mb-6">
              With over 15 years of experience in family medicine, Dr. Chen brings expertise,
              compassion, and dedication to every patient interaction. Board-certified in
              Internal Medicine, she believes in a holistic approach to healthcare.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col items-center p-4 bg-blue-50 rounded-lg">
                <Award className="w-8 h-8 text-blue-600 mb-2" />
                <h3 className="font-semibold">Board Certified</h3>
              </div>
              <div className="flex flex-col items-center p-4 bg-blue-50 rounded-lg">
                <BookOpen className="w-8 h-8 text-blue-600 mb-2" />
                <h3 className="font-semibold">15+ Years Exp.</h3>
              </div>
              <div className="flex flex-col items-center p-4 bg-blue-50 rounded-lg">
                <Users className="w-8 h-8 text-blue-600 mb-2" />
                <h3 className="font-semibold">10k+ Patients</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}