import React from 'react';

export function Hero() {
  return (
    <section className="pt-24 pb-12 bg-gradient-to-br from-blue-50 to-white">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
        <div className="md:w-1/2 mb-8 md:mb-0">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Your Health Is Our
            <span className="text-blue-600"> Priority</span>
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Providing compassionate, comprehensive care with a focus on your well-being.
            Schedule your appointment today and take the first step towards better health.
          </p>
          <div className="flex space-x-4">
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Book Appointment
            </button>
            <button className="border-2 border-blue-600 text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 transition-colors">
              Learn More
            </button>
          </div>
        </div>
        <div className="md:w-1/2">
          <img
            src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=800"
            alt="Doctor with stethoscope"
            className="rounded-2xl shadow-lg"
          />
        </div>
      </div>
    </section>
  );
}